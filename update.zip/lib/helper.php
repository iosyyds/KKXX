<?php
/**
 * KKXX 公共工具函数库（多用户版）
 * 包含：基础工具 / 管理员会话 / App 用户令牌鉴权 / 数据读写 / 备份导出 / 后台布局 / 内联 SVG 图标
 */

declare(strict_types=1);

if (!defined('KKXX_ROOT')) {
    define('KKXX_ROOT', dirname(__DIR__));
}

// ---------------- 基础工具 ----------------

function e(?string $s): string
{
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function json_out(int $code, string $msg, $data = null): void
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['code' => $code, 'msg' => $msg, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function body_json(): array
{
    $raw = file_get_contents('php://input');
    $d = json_decode($raw, true);
    return is_array($d) ? $d : [];
}

function ms_now(): int
{
    return (int) round(microtime(true) * 1000);
}

function is_installed(): bool
{
    $c = @include KKXX_ROOT . '/config/db.php';
    return is_array($c) && !empty($c['dbname']) && !empty($c['user']);
}

// ---------------- 设置项 ----------------

function settings_get(string $k, $default = null)
{
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        try {
            foreach (Db::all('SELECT s_key, s_value FROM kkxx_settings') as $row) {
                $cache[$row['s_key']] = $row['s_value'];
            }
        } catch (Throwable $e) {
            $cache = [];
        }
    }
    return array_key_exists($k, $cache) ? $cache[$k] : $default;
}

function settings_set(string $k, string $v): void
{
    Db::exec(
        'INSERT INTO kkxx_settings (s_key, s_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE s_value = VALUES(s_value)',
        [$k, $v]
    );
}

// ---------------- 旧库自动迁移（老版本数据库升级到多用户版） ----------------

function migrate_if_needed(): void
{
    static $done = false;
    if ($done) {
        return;
    }
    try {
        $pdo = Db::pdo();

        if (!$pdo->query("SHOW TABLES LIKE 'kkxx_users'")->fetchColumn()) {
            $pdo->exec("CREATE TABLE IF NOT EXISTS kkxx_users (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                email VARCHAR(190) NOT NULL,
                pass VARCHAR(255) NOT NULL,
                status TINYINT NOT NULL DEFAULT 1,
                created_at INT UNSIGNED NOT NULL DEFAULT 0,
                updated_at INT UNSIGNED NOT NULL DEFAULT 0,
                last_login_at INT UNSIGNED NOT NULL DEFAULT 0,
                PRIMARY KEY (id),
                UNIQUE KEY uk_email (email)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("CREATE TABLE IF NOT EXISTS kkxx_tokens (
                token VARCHAR(64) NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                created_at INT UNSIGNED NOT NULL DEFAULT 0,
                expires_at INT UNSIGNED NOT NULL DEFAULT 0,
                PRIMARY KEY (token),
                KEY idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        }

        // 用户资料字段（新功能：老库自动补列）
        foreach (['nickname' => "VARCHAR(100) NOT NULL DEFAULT ''", 'avatar' => "TEXT NULL"] as $col => $type) {
            if (!$pdo->query("SHOW COLUMNS FROM kkxx_users LIKE '$col'")->fetchColumn()) {
                $pdo->exec("ALTER TABLE kkxx_users ADD COLUMN `$col` $type");
            }
        }

        foreach (['kkxx_notes', 'kkxx_todos', 'kkxx_bills', 'kkxx_checkins'] as $t) {
            if (!$pdo->query("SHOW COLUMNS FROM `$t` LIKE 'user_id'")->fetchColumn()) {
                $pdo->exec("ALTER TABLE `$t` ADD COLUMN user_id INT UNSIGNED NOT NULL DEFAULT 0 AFTER id, ADD KEY idx_user (user_id)");
            }
        }

        // 药盒表（新功能：老库自动补建）
        $pdo->exec("CREATE TABLE IF NOT EXISTS kkxx_medbox (
            id VARCHAR(64) NOT NULL,
            user_id INT UNSIGNED NOT NULL DEFAULT 0,
            name VARCHAR(255) NOT NULL DEFAULT '',
            purpose MEDIUMTEXT,
            `usage` MEDIUMTEXT,
            contraindication MEDIUMTEXT,
            expiry_date BIGINT NOT NULL DEFAULT 0,
            manufacturer VARCHAR(255) NOT NULL DEFAULT '',
            tags TEXT,
            images MEDIUMTEXT,
            created_at BIGINT NOT NULL DEFAULT 0,
            updated_at BIGINT NOT NULL DEFAULT 0,
            deleted TINYINT NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            KEY idx_user (user_id),
            KEY idx_medbox_expiry (expiry_date),
            KEY idx_medbox_updated (updated_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // KX 号（每个用户唯一数字 ID）
        if (!$pdo->query("SHOW COLUMNS FROM kkxx_users LIKE 'kx_number'")->fetchColumn()) {
            $pdo->exec("ALTER TABLE kkxx_users ADD COLUMN kx_number VARCHAR(20) NOT NULL DEFAULT '' AFTER email, ADD KEY idx_kx (kx_number)");
        }
        // 所有用户统一重置 KX 号（从 1000 开始，按注册顺序），只跑一次
        if (settings_get('kx_reset_done', '0') !== '1') {
            foreach (Db::all("SELECT id FROM kkxx_users ORDER BY id ASC") as $i => $u) {
                $kx = (string)(1000 + $i);
                Db::exec("UPDATE kkxx_users SET kx_number = ? WHERE id = ?", [$kx, (int)$u['id']]);
            }
            settings_set('kx_reset_done', '1');
        }

        // 好友关系表
        $pdo->exec("CREATE TABLE IF NOT EXISTS kkxx_friends (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            friend_id INT NOT NULL,
            created_at BIGINT NOT NULL DEFAULT 0,
            UNIQUE KEY pair (user_id, friend_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // 好友申请表
        $pdo->exec("CREATE TABLE IF NOT EXISTS kkxx_friend_requests (
            id INT AUTO_INCREMENT PRIMARY KEY,
            from_user INT NOT NULL,
            to_user INT NOT NULL,
            message VARCHAR(255) NOT NULL DEFAULT '',
            status TINYINT NOT NULL DEFAULT 0,
            created_at BIGINT NOT NULL DEFAULT 0,
            KEY idx_to (to_user, status)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // 聊天消息表
        $pdo->exec("CREATE TABLE IF NOT EXISTS kkxx_messages (
            id INT AUTO_INCREMENT PRIMARY KEY,
            from_user INT NOT NULL,
            to_user INT NOT NULL,
            text TEXT,
            is_read TINYINT NOT NULL DEFAULT 0,
            created_at BIGINT NOT NULL DEFAULT 0,
            KEY idx_pair (from_user, to_user, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        if (!$pdo->query("SHOW COLUMNS FROM `kkxx_sync_log` LIKE 'user_email'")->fetchColumn()) {
            $pdo->exec("ALTER TABLE `kkxx_sync_log` ADD COLUMN user_email VARCHAR(190) NOT NULL DEFAULT '' AFTER counts");
        }

        foreach (['app_version', 'update_note', 'announcement_title', 'announcement_content', 'announcement_enabled'] as $k) {
            if (settings_get($k, null) === null) {
                settings_set($k, '');
            }
        }
        if (settings_get('app_version', '') === '') {
            settings_set('app_version', '1.1.0');
        }
        $done = true;
    } catch (Throwable $e) {
        // 未安装 / 连接失败时静默跳过
    }
}

/** 首个注册用户自动继承历史遗留数据（user_id = 0） */
function adopt_orphan_data(int $userId): void
{
    foreach (['kkxx_notes', 'kkxx_todos', 'kkxx_bills', 'kkxx_checkins', 'kkxx_medbox'] as $t) {
        Db::exec("UPDATE `$t` SET user_id = ? WHERE user_id = 0", [$userId]);
    }
}

// ---------------- 管理员鉴权 ----------------

function key_hash(string $key): string
{
    $c = require KKXX_ROOT . '/config/db.php';
    $salt = is_array($c) && !empty($c['salt']) ? $c['salt'] : 'kkxx';
    return hash('sha256', $salt . '::' . $key);
}

function verify_key(?string $key): bool
{
    if ($key === null || $key === '') {
        return false;
    }
    $stored = settings_get('admin_key_hash', '');
    if ($stored === '') {
        return false;
    }
    return hash_equals($stored, key_hash($key));
}

function admin_start(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_name('kkxx_admin');
        session_start();
    }
}

function require_admin(): void
{
    admin_start();
    migrate_if_needed();
    if (empty($_SESSION['kkxx_admin'])) {
        header('Location: login.php');
        exit;
    }
}

function csrf_token(): string
{
    admin_start();
    if (empty($_SESSION['kkxx_csrf'])) {
        $_SESSION['kkxx_csrf'] = bin2hex(random_bytes(16));
    }
    return $_SESSION['kkxx_csrf'];
}

function csrf_check(): void
{
    admin_start();
    $t = $_POST['csrf'] ?? '';
    if ($t === '' || !hash_equals($_SESSION['kkxx_csrf'] ?? '', (string) $t)) {
        json_out(403, 'CSRF 校验失败，请刷新页面重试');
    }
}

// ---------------- App 用户令牌鉴权 ----------------

function bearer_token(): ?string
{
    $h = function_exists('getallheaders') ? getallheaders() : [];
    foreach (['X-Token', 'X-Access-Token'] as $k) {
        if (isset($h[$k]) && trim($h[$k]) !== '') {
            return trim($h[$k]);
        }
    }
    if (isset($h['Authorization']) && stripos($h['Authorization'], 'bearer ') === 0) {
        return trim(substr($h['Authorization'], 7));
    }
    foreach (['token'] as $p) {
        if (isset($_GET[$p]) && trim((string) $_GET[$p]) !== '') {
            return trim((string) $_GET[$p]);
        }
        if (isset($_POST[$p]) && trim((string) $_POST[$p]) !== '') {
            return trim((string) $_POST[$p]);
        }
    }
    return null;
}

/** 校验 App 登录令牌，返回用户行；失败直接输出 JSON 并结束 */
function require_user(): array
{
    if (!is_installed()) {
        json_out(500, '系统尚未安装，请先访问 /install');
    }
    migrate_if_needed();
    $token = bearer_token();
    if ($token === null || $token === '') {
        json_out(401, '未登录，请先登录');
    }
    $row = Db::one(
        'SELECT u.* FROM kkxx_tokens t JOIN kkxx_users u ON u.id = t.user_id
         WHERE t.token = ? AND t.expires_at > ? AND u.status = 1',
        [$token, time()]
    );
    if ($row === null) {
        json_out(401, '登录已过期，请重新登录');
    }
    return $row;
}

/** 签发登录令牌（30 天有效） */
function issue_token(int $userId): string
{
    $token = bin2hex(random_bytes(32));
    Db::exec(
        'INSERT INTO kkxx_tokens (token, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)',
        [$token, $userId, time(), time() + 86400 * 30]
    );
    return $token;
}

/** 同步总开关检查（登录后同步类接口用） */
function sync_gate(): void
{
    if (settings_get('sync_enabled', '1') !== '1') {
        json_out(403, '云端同步已由管理员关闭');
    }
}

// ---------------- 数据读取与规范化 ----------------

function norm_row(string $table, array $row): array
{
    $listFields = ['kkxx_notes' => ['images', 'tags'], 'kkxx_todos' => ['tags'], 'kkxx_medbox' => ['tags', 'images']];
    $lists = $listFields[$table] ?? [];
    foreach ($lists as $f) {
        $v = json_decode((string) ($row[$f] ?? '[]'), true);
        $row[$f] = is_array($v) ? $v : [];
    }
    // deleted 统一输出布尔（App 端模型为 Bool）
    if (array_key_exists('deleted', $row)) {
        $row['deleted'] = (bool) $row['deleted'];
    }
    return $row;
}

function module_tables(): array
{
    return [
        'notes'    => 'kkxx_notes',
        'todos'    => 'kkxx_todos',
        'bills'    => 'kkxx_bills',
        'checkins' => 'kkxx_checkins',
        'medbox'   => 'kkxx_medbox',
    ];
}

/**
 * 拉取数据。$userId 为 null 时返回全部用户（后台导出用）；
 * 传用户 id 时仅返回该用户数据（App 用）。
 */
function full_payload(?int $userId = null): array
{
    $uidSql = $userId === null ? '' : 'WHERE user_id = ' . (int) $userId;
    $notes = array_map(fn($r) => norm_row('kkxx_notes', $r),
        Db::all("SELECT id, title, content, images, tags, created_at AS createdAt, updated_at AS updatedAt, deleted FROM kkxx_notes $uidSql"));
    $todos = array_map(fn($r) => norm_row('kkxx_todos', $r),
        Db::all("SELECT id, title, done, due_date AS dueDate, tags, created_at AS createdAt, updated_at AS updatedAt, deleted FROM kkxx_todos $uidSql"));
    $bills = array_map(fn($r) => norm_row('kkxx_bills', $r),
        Db::all("SELECT id, type, amount, category, remark, bill_date AS billDate, created_at AS createdAt, updated_at AS updatedAt, deleted FROM kkxx_bills $uidSql"));
    $checkins = array_map(fn($r) => norm_row('kkxx_checkins', $r),
        Db::all("SELECT id, date, note, created_at AS createdAt, updated_at AS updatedAt, deleted FROM kkxx_checkins $uidSql"));
    $medbox = array_map(fn($r) => norm_row('kkxx_medbox', $r),
        Db::all("SELECT id, name, purpose, `usage`, contraindication, expiry_date AS expiryDate, manufacturer, tags, images, created_at AS createdAt, updated_at AS updatedAt, deleted FROM kkxx_medbox $uidSql"));

    return [
        'notes'       => $notes,
        'todos'       => $todos,
        'bills'       => $bills,
        'checkins'    => $checkins,
        'medbox'      => $medbox,
        'server_time' => ms_now(),
    ];
}

// ---------------- 实体 Upsert（LWW：新时间戳覆盖旧时间戳，按用户隔离） ----------------

function upsert_entities(string $table, array $items, int $userId = 0): array
{
    $specs = [
        'kkxx_notes' => [
            'cols' => ['id', 'user_id', 'title', 'content', 'images', 'tags', 'created_at', 'updated_at', 'deleted'],
            'map'  => function (array $it, int $ts, int $uid) {
                return [
                    $it['id'],
                    $uid,
                    (string) ($it['title'] ?? ''),
                    (string) ($it['content'] ?? ''),
                    json_encode($it['images'] ?? [], JSON_UNESCAPED_UNICODE),
                    json_encode($it['tags'] ?? [], JSON_UNESCAPED_UNICODE),
                    (int) ($it['createdAt'] ?? $ts),
                    $ts,
                    (int) ($it['deleted'] ?? 0),
                ];
            },
        ],
        'kkxx_todos' => [
            'cols' => ['id', 'user_id', 'title', 'done', 'due_date', 'tags', 'created_at', 'updated_at', 'deleted'],
            'map'  => function (array $it, int $ts, int $uid) {
                return [
                    $it['id'],
                    $uid,
                    (string) ($it['title'] ?? ''),
                    (int) ($it['done'] ?? 0),
                    (int) ($it['dueDate'] ?? 0),
                    json_encode($it['tags'] ?? [], JSON_UNESCAPED_UNICODE),
                    (int) ($it['createdAt'] ?? $ts),
                    $ts,
                    (int) ($it['deleted'] ?? 0),
                ];
            },
        ],
        'kkxx_bills' => [
            'cols' => ['id', 'user_id', 'type', 'amount', 'category', 'remark', 'bill_date', 'created_at', 'updated_at', 'deleted'],
            'map'  => function (array $it, int $ts, int $uid) {
                $type = ($it['type'] ?? 'expense') === 'income' ? 'income' : 'expense';
                return [
                    $it['id'],
                    $uid,
                    $type,
                    (float) ($it['amount'] ?? 0),
                    (string) ($it['category'] ?? ''),
                    (string) ($it['remark'] ?? ''),
                    (int) ($it['billDate'] ?? $ts),
                    (int) ($it['createdAt'] ?? $ts),
                    $ts,
                    (int) ($it['deleted'] ?? 0),
                ];
            },
        ],
        'kkxx_checkins' => [
            'cols' => ['id', 'user_id', 'date', 'note', 'created_at', 'updated_at', 'deleted'],
            'map'  => function (array $it, int $ts, int $uid) {
                return [
                    $it['id'],
                    $uid,
                    (string) ($it['date'] ?? ''),
                    (string) ($it['note'] ?? ''),
                    (int) ($it['createdAt'] ?? $ts),
                    $ts,
                    (int) ($it['deleted'] ?? 0),
                ];
            },
        ],
        'kkxx_medbox' => [
            'cols' => ['id', 'user_id', 'name', 'purpose', 'usage', 'contraindication', 'expiry_date', 'manufacturer', 'tags', 'images', 'created_at', 'updated_at', 'deleted'],
            'map'  => function (array $it, int $ts, int $uid) {
                return [
                    $it['id'],
                    $uid,
                    (string) ($it['name'] ?? ''),
                    (string) ($it['purpose'] ?? ''),
                    (string) ($it['usage'] ?? ''),
                    (string) ($it['contraindication'] ?? ''),
                    (int) ($it['expiryDate'] ?? 0),
                    (string) ($it['manufacturer'] ?? ''),
                    json_encode($it['tags'] ?? [], JSON_UNESCAPED_UNICODE),
                    json_encode($it['images'] ?? [], JSON_UNESCAPED_UNICODE),
                    (int) ($it['createdAt'] ?? $ts),
                    $ts,
                    (int) ($it['deleted'] ?? 0),
                ];
            },
        ],
    ];

    $spec = $specs[$table] ?? null;
    if ($spec === null) {
        return [0, 0];
    }

    $cols = $spec['cols'];
    $place = rtrim(str_repeat('?,', count($cols)), ',');
    $update = [];
    foreach (array_slice($cols, 1) as $c) {
        $update[] = "`$c`=VALUES(`$c`)";
    }
    $sql = "INSERT INTO `$table` (`" . implode('`,`', $cols) . "`) VALUES ($place)
            ON DUPLICATE KEY UPDATE " . implode(',', $update);

    $accepted = 0;
    $skipped = 0;
    foreach ($items as $it) {
        if (!is_array($it) || empty($it['id']) || !is_string($it['id'])) {
            $skipped++;
            continue;
        }
        $ts = (int) ($it['updatedAt'] ?? 0);
        $old = Db::one("SELECT updated_at FROM `$table` WHERE id = ?", [$it['id']]);
        if ($old !== null && (int) $old['updated_at'] > $ts) {
            $skipped++;
            continue;
        }
        Db::exec($sql, $spec['map']($it, $ts, $userId));
        $accepted++;
    }
    return [$accepted, $skipped];
}

function record_sync(?string $device, string $action, array $counts = [], ?string $email = null): void
{
    Db::exec(
        'INSERT INTO kkxx_sync_log (device, action, counts, user_email, created_at) VALUES (?, ?, ?, ?, ?)',
        [$device ?? 'unknown', $action, json_encode($counts, JSON_UNESCAPED_UNICODE), $email ?? '', time()]
    );
    settings_set('last_sync_time', (string) time());
    settings_set('last_sync_device', (string) ($device ?? 'unknown'));
}

// ---------------- 备份 ----------------

function backup_dir(): string
{
    return KKXX_ROOT . '/backups';
}

function backup_tables(): string
{
    $dir = backup_dir();
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $file = 'kkxx-' . date('Ymd-His') . '.sql';
    $path = $dir . '/' . $file;

    $tables = ['kkxx_settings', 'kkxx_users', 'kkxx_tokens', 'kkxx_notes', 'kkxx_todos', 'kkxx_bills', 'kkxx_checkins', 'kkxx_medbox', 'kkxx_sync_log'];
    $out = "-- KKXX database backup\n-- Generated: " . date('c') . "\nSET NAMES utf8mb4;\n\n";
    foreach ($tables as $t) {
        $rows = Db::all("SELECT * FROM `$t`");
        $out .= "TRUNCATE TABLE `$t`;\n";
        foreach ($rows as $r) {
            $cols = array_map(fn($c) => "`$c`", array_keys($r));
            $vals = array_map(function ($v) {
                return $v === null ? 'NULL' : Db::pdo()->quote((string) $v);
            }, array_values($r));
            $out .= "INSERT INTO `$t` (" . implode(',', $cols) . ") VALUES (" . implode(',', $vals) . ");\n";
        }
        $out .= "\n";
    }
    file_put_contents($path, $out);

    // 仅保留最近 10 份备份
    $files = glob($dir . '/kkxx-*.sql') ?: [];
    usort($files, fn($a, $b) => filemtime($a) <=> filemtime($b));
    while (count($files) > 10) {
        unlink(array_shift($files));
    }
    return $file;
}

function restore_sql_file(string $path): bool
{
    $sql = file_get_contents($path);
    if ($sql === false || trim($sql) === '') {
        return false;
    }
    Db::pdo()->exec($sql); // PDO 模拟预处理默认开启，可执行多语句
    return true;
}

/** 后台 JSON 恢复用：按原始行（含 user_id）写回单条记录 */
function restore_raw_row(string $table, array $row): void
{
    $specs = [
        'kkxx_notes'    => ['id', 'user_id', 'title', 'content', 'images', 'tags', 'created_at', 'updated_at', 'deleted'],
        'kkxx_todos'    => ['id', 'user_id', 'title', 'done', 'due_date', 'tags', 'created_at', 'updated_at', 'deleted'],
        'kkxx_bills'    => ['id', 'user_id', 'type', 'amount', 'category', 'remark', 'bill_date', 'created_at', 'updated_at', 'deleted'],
        'kkxx_checkins' => ['id', 'user_id', 'date', 'note', 'created_at', 'updated_at', 'deleted'],
        'kkxx_medbox'   => ['id', 'user_id', 'name', 'purpose', 'usage', 'contraindication', 'expiry_date', 'manufacturer', 'tags', 'images', 'created_at', 'updated_at', 'deleted'],
    ];
    $cols = $specs[$table] ?? null;
    if ($cols === null) {
        return;
    }
    $vals = [];
    foreach ($cols as $c) {
        $vals[] = $row[$c] ?? ($c === 'user_id' ? 0 : '');
    }
    // 兼容 API 形态字段（camelCase）
    if (array_key_exists('createdAt', $row) && !array_key_exists('created_at', $row)) {
        $vals[array_search('created_at', $cols, true)] = $row['createdAt'];
    }
    if (array_key_exists('updatedAt', $row) && !array_key_exists('updated_at', $row)) {
        $vals[array_search('updated_at', $cols, true)] = $row['updatedAt'];
    }
    if (array_key_exists('dueDate', $row) && !array_key_exists('due_date', $row)) {
        $vals[array_search('due_date', $cols, true)] = $row['dueDate'];
    }
    if (array_key_exists('billDate', $row) && !array_key_exists('bill_date', $row)) {
        $vals[array_search('bill_date', $cols, true)] = $row['billDate'];
    }
    if (array_key_exists('expiryDate', $row) && !array_key_exists('expiry_date', $row)) {
        $vals[array_search('expiry_date', $cols, true)] = $row['expiryDate'];
    }
    if (in_array('images', $cols, true) && is_array($row['images'] ?? null)) {
        $vals[array_search('images', $cols, true)] = json_encode($row['images'], JSON_UNESCAPED_UNICODE);
    }
    if (in_array('tags', $cols, true) && is_array($row['tags'] ?? null)) {
        $vals[array_search('tags', $cols, true)] = json_encode($row['tags'], JSON_UNESCAPED_UNICODE);
    }

    $place = rtrim(str_repeat('?,', count($cols)), ',');
    $sql = "INSERT INTO `$table` (`" . implode('`,`', $cols) . "`) VALUES ($place)
            ON DUPLICATE KEY UPDATE `id` = `id`";
    Db::exec($sql, $vals);
}

// ---------------- 导出 ----------------

function export_json(string $filename, array $data): void
{
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

function export_excel(string $filename, array $sheets): void
{
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "\xEF\xBB\xBF"; // UTF-8 BOM，Excel 可正确识别中文
    echo '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel"><head><meta charset="utf-8"><style>td,th{border:1px solid #ccc;padding:4px 8px;}</style></head><body>';
    foreach ($sheets as $sheet) {
        echo '<h3>' . e($sheet['name']) . '</h3><table>';
        echo '<tr>';
        foreach ($sheet['headers'] as $h) {
            echo '<th>' . e((string) $h) . '</th>';
        }
        echo '</tr>';
        foreach ($sheet['rows'] as $row) {
            echo '<tr>';
            foreach ($row as $cell) {
                echo '<td>' . e((string) $cell) . '</td>';
            }
            echo '</tr>';
        }
        echo '</table><br/>';
    }
    echo '</body></html>';
    exit;
}

// ---------------- 后台布局 ----------------

function admin_header(string $title, string $active): void
{
    $nav = [
        'index'    => ['仪表盘', 'home'],
        'users'    => ['用户管理', 'user'],
        'data'     => ['数据总览', 'list'],
        'version'  => ['版本管理', 'download'],
        'announce' => ['公告管理', 'alert'],
        'config'   => ['系统配置', 'settings'],
        'update'   => ['在线更新', 'cloud'],
    ];
    echo '<!DOCTYPE html><html lang="zh-CN"><head>';
    echo '<meta charset="utf-8">';
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">';
    echo '<meta name="csrf" content="' . e(csrf_token()) . '">';
    echo '<title>' . e($title) . ' - KKXX 管理后台</title>';
    echo '<link rel="stylesheet" href="assets/css/style.css">';
    echo '</head><body data-page="' . e($active) . '">';
    echo '<aside class="sidebar">';
    echo '<div class="brand">' . svg('checkin', 22) . '<span>KKXX 后台</span></div>';
    echo '<nav class="nav">';
    foreach ($nav as $key => [$label, $icon]) {
        $cls = $active === $key ? 'active' : '';
        echo '<a class="' . $cls . '" href="' . $key . '.php">' . svg($icon) . '<span>' . e($label) . '</span></a>';
    }
    echo '</nav>';
    echo '<a class="logout" href="login.php?logout=1">' . svg('logout') . '<span>退出登录</span></a>';
    echo '</aside>';
    echo '<main class="main">';
    echo '<header class="topbar"><h1>' . e($title) . '</h1></header>';
    echo '<div class="content">';
}

function admin_footer(): void
{
    echo '</div></main>';
    echo '<script src="assets/js/main.js"></script>';
    echo '</body></html>';
}

function fmt_ms(int $ms): string
{
    if ($ms <= 0) {
        return '-';
    }
    return date('Y-m-d H:i', (int) ($ms / 1000));
}

function fmt_time(int $ts): string
{
    return $ts > 0 ? date('Y-m-d H:i', $ts) : '-';
}

/** 后台展示用：查询某用户各模块数量 */
function user_module_counts(int $userId): array
{
    $out = ['notes' => 0, 'todos' => 0, 'bills' => 0, 'checkins' => 0, 'medbox' => 0];
    $map = ['notes' => 'kkxx_notes', 'todos' => 'kkxx_todos', 'bills' => 'kkxx_bills', 'checkins' => 'kkxx_checkins', 'medbox' => 'kkxx_medbox'];
    foreach ($map as $k => $t) {
        $out[$k] = (int) Db::scalar("SELECT COUNT(*) FROM `$t` WHERE user_id = ? AND deleted = 0", [$userId]);
    }
    return $out;
}

// ---------------- 内联 SVG 图标库（fill="currentColor" 跟随主题） ----------------

function svg(string $name, int $size = 20): string
{
    $paths = [
        'home'     => 'M10 20v-6h4v6h5v-8h3L12 3 2 12h3v8z',
        'note'     => 'M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
        'todo'     => 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
        'bill'     => 'M21 18v1c0 1.1-.9 2-2 2H5c-1.11 0-2-.9-2-2V5c0-1.1.89-2 2-2h14c1.1 0 2 .9 2 2v1h-9c-1.11 0-2 .9-2 2v8c0 1.1.89 2 2 2h9zm-9-2h10V8H12v8zm4-2.5c-.83 0-1.5-.67-1.5-1.5s.67-1.5 1.5-1.5 1.5.67 1.5 1.5-.67 1.5-1.5 1.5z',
        'checkin'  => 'M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM8.29 12.29L7 13.58 10.41 17 17 10.41 15.71 9.12l-5.3 5.3z',
        'tools'    => 'M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z',
        'data'     => 'M5 9.2h3V19H5zM10.6 5h2.8v14h-2.8zm5.6 8H19v6h-2.8z',
        'sync'     => 'M12 4V1L8 5l4 4V6c3.31 0 6 2.69 6 6 0 1.01-.25 1.97-.7 2.8l1.46 1.46C19.54 15.03 20 13.57 20 12c0-4.42-3.58-8-8-8zm0 14c-3.31 0-6-2.69-6-6 0-1.01.25-1.97.7-2.8L5.24 7.74C4.46 8.97 4 10.43 4 12c0 4.42 3.58 8 7.99 8v3l4-4-4-4v3z',
        'settings' => 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36-2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
        'search'   => 'M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
        'add'      => 'M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z',
        'edit'     => 'M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z',
        'delete'   => 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
        'download' => 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z',
        'cloud'    => 'M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z',
        'upload'   => 'M9 16h6v-6h4l-7-7-7 7h4v6zm-4 2h14v2H5v-2z',
        'refresh'  => 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
        'close'    => 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
        'check'    => 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
        'back'     => 'M20 11H7.83l5.59-5.59L12 4l-8 8 8 8 1.41-1.41L7.83 13H20v-2z',
        'lock'     => 'M18 8h-1V6c0-2.76-2.24-5-5-5S7 3.24 7 6v2H6c-1.1 0-2 .9-2 2v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10c0-1.1-.9-2-2-2zm-6 9c-1.1 0-2-.9-2-2s.9-2 2-2 2 .9 2 2-.9 2-2 2zm3.1-9H8.9V6c0-1.71 1.39-3.1 3.1-3.1 1.71 0 3.1 1.39 3.1 3.1v2z',
        'export'   => 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z',
        'clear'    => 'M15 16h4v2h-4zm0-8h7v2h-7zm0 4h6v2h-6zM3 18c0 1.1.9 2 2 2h6c1.1 0 2-.9 2-2V8H3v10zM14 5h-3l-1-1H6L5 5H2v2h12V5z',
        'logout'   => 'M17 7l-1.41 1.41L18.17 11H8v2h10.17l-2.58 2.58L17 17l5-5zM4 5h8V3H4c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h8v-2H4V5z',
        'save'     => 'M17 3H5c-1.11 0-2 .9-2 2v14c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V7l-4-4zm-5 16c-1.66 0-3-1.34-3-3s1.34-3 3-3 3 1.34 3 3-1.34 3-3 3zm3-10H5V5h10v4z',
        'clock'    => 'M11.99 2C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8zm.5-13H11v6l5.25 3.15.75-1.23-4.5-2.67z',
        'db'       => 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
        'user'     => 'M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z',
        'file'     => 'M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zM13 9V3.5L18.5 9H13z',
        'list'     => 'M3 13h2v-2H3v2zm0 4h2v-2H3v2zm0-8h2V7H3v2zm4 4h14v-2H7v2zm0 4h14v-2H7v2zM7 7v2h14V7H7z',
        'alert'    => 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-2h2v2zm0-4h-2V7h2v6z',
        'filter'   => 'M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z',
        'rocket'   => 'M12 2c3 0 5 1.5 6 5 1.5 3 .5 6-1 8.5-.8 1.3-2 2.5-3 3v3l-4-2-4 2v-3c-1-.5-2.2-1.7-3-3C.5 13-.5 10 1 7 2 3.5 4 2 7 2c1.5 0 3 .8 4 1.6C11 2.8 11.5 2 12 2zm-3 12c1.1 0 2-.9 2-2s-.9-2-2-2-2 .9-2 2 .9 2 2 2z',
        'megaphone' => 'M20 4c-.6 0-1.1.2-1.5.6L15 8H8c-.6 0-1 .4-1 1v6c0 .6.4 1 1 1h7l3.5 3.4c.4.4.9.6 1.5.6.6 0 1-.4 1-1V5c0-.6-.4-1-1-1zM4 12H2v2h2v-2zm1-5H3v2h2V7z',
        'tag'      => 'M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z',
        'pill'     => 'M17 5v2H7V5h10zM18 3H6c-.55 0-1 .45-1 1v1c0 .55.45 1 1 1h12c.55 0 1-.45 1-1V4c0-.55-.45-1-1-1zM17 7H7c-1.1 0-2 .9-2 2v9c0 1.1.9 2 2 2h10c1.1 0 2-.9 2-2V9c0-1.1-.9-2-2-2zm-5 11.5c-1.93 0-3.5-1.57-3.5-3.5s1.57-3.5 3.5-3.5 3.5 1.57 3.5 3.5-1.57 3.5-3.5 3.5zm0-5.5c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z',
    ];
    $d = $paths[$name] ?? $paths['list'];
    return '<svg class="icon" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="' . $d . '"/></svg>';
}
