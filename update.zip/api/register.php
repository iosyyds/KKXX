<?php
/**
 * /api/register.php —— App 用户注册
 * 入参（JSON Body）：{"email":"user@example.com","password":"******"}
 * 出参：{"code":0,"msg":"ok","data":{"token":"...","email":"...","server_time":...}}
 * 说明：首个注册用户自动继承历史遗留数据（老版本单用户数据）
 */
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/helper.php';

if (!is_installed()) {
    json_out(500, '系统尚未安装，请先访问 /install');
}
migrate_if_needed();

$body = body_json();
$email = strtolower(trim((string) ($body['email'] ?? '')));
$pass  = (string) ($body['password'] ?? '');

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    json_out(1, '邮箱格式不正确');
}
if (strlen($pass) < 6) {
    json_out(1, '密码至少 6 位');
}
if (Db::one('SELECT id FROM kkxx_users WHERE email = ?', [$email]) !== null) {
    json_out(1, '该邮箱已注册，请直接登录');
}

$isFirst = (int) Db::scalar('SELECT COUNT(*) FROM kkxx_users') === 0;
$now = time();

Db::exec(
    'INSERT INTO kkxx_users (email, pass, status, created_at, updated_at, last_login_at) VALUES (?, ?, 1, ?, ?, ?)',
    [$email, password_hash($pass, PASSWORD_DEFAULT), $now, $now, $now]
);
$uid = Db::lastId();

// 分配 KX 号（当前最大 +1，从 1000 起）
$maxKx = (int) Db::scalar("SELECT MAX(CAST(kx_number AS UNSIGNED)) FROM kkxx_users WHERE kx_number REGEXP '^[0-9]+$'");
Db::exec("UPDATE kkxx_users SET kx_number = ? WHERE id = ?", [(string)max(1000, $maxKx + 1), $uid]);

// 首个用户继承旧数据
if ($isFirst) {
    adopt_orphan_data($uid);
}

$token = issue_token($uid);
record_sync('app', 'register', ['user_id' => $uid], $email);

json_out(0, 'ok', [
    'token'       => $token,
    'email'       => $email,
    'user_id'     => $uid,
    'server_time' => ms_now(),
]);
