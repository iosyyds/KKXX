<?php
/**
 * /api/profile.php —— 用户资料（昵称 / 头像）
 * POST Body: {"action":"get"}                       → 拉取资料
 * POST Body: {"action":"update","nickname":"..","avatar":"<base64 png>"} → 更新资料
 * 出参：{"code":0,"msg":"ok","data":{"nickname":"","avatar":"","email":"..."}}
 */
require __DIR__ . '/../lib/db.php';
require __DIR__ . '/../lib/helper.php';

$user = require_user();
$body = body_json();
$action = (string) ($body['action'] ?? 'get');

if ($action === 'get') {
    json_out(0, 'ok', [
        'nickname' => (string) ($user['nickname'] ?? ''),
        'avatar'   => (string) ($user['avatar'] ?? ''),
        'email'    => (string) $user['email'],
    ]);
}

if ($action === 'update') {
    $nick = trim(mb_substr((string) ($body['nickname'] ?? ''), 0, 30));
    $avatar = (string) ($body['avatar'] ?? '');
    // 头像过大或格式错则保留旧头像，不阻塞昵称保存
    if (strlen($avatar) > 200000 || ($avatar !== '' && base64_decode($avatar, true) === false)) {
        $avatar = (string) ($user['avatar'] ?? '');
    }
    Db::exec(
        'UPDATE kkxx_users SET nickname = ?, avatar = ?, updated_at = ? WHERE id = ?',
        [$nick, $avatar === '' ? null : $avatar, time(), (int) $user['id']]
    );
    record_sync('app', 'profile_update', [], (string) $user['email']);
    json_out(0, 'ok', [
        'nickname' => $nick,
        'avatar'   => $avatar,
        'email'    => (string) $user['email'],
    ]);
}

json_out(1, '未知操作');
